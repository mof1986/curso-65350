// let validar = false 

// if (validar) {
//     console.log("Variable verdadera")
// }


// let fruta = "sandia"
// let mes = "febrero"
// let edad = 18


// if (fruta == "sandia") {
//     console.log("Felicitaciones, estamos en el verano")
// } else if (fruta == "mandarina") {
//     console.log("Me parece que es otoño")
// } else {
//     console.log("Puede ser cualquier otra fruta")
// }

// OR ||

// if (fruta == "sandia" || fruta == "melon") {
//     console.log("Efectivamente es verano")
// }

// AND &&

// if (fruta == "sandia" && (mes == "enero" || mes == "febrero" || mes == "marzo" || mes == "diciembre")) {
//     console.log("Fruta y mes veraniego")
// }

// if (edad >= 18) {
//     console.log("Sos mayor de edad, podes ingresar a la vinoteca")
// } else {
//     console.log("Sos menor, no se te puede vender alcohol")
// }



// FOR


// for ("desde"; "hasta"; "actualizacion") {
//     // bloque de codigo
// }

// for (let i=1; i<=10; i++) {
//     console.log(i)
// }

// let numero = parseInt(prompt("Ingrese la tabla de multiplicar que desea"))
// for (let i=1; i<=15; i++) {
//     let resultado = i*numero
//     console.log(numero+"x"+i+": "+resultado)
// }


// for (let i=10; i>=1; i--){
    
//     console.log(i)
//     if(i===2) {
//         console.log("abortamos depegue")
//         break
//     }
//     if(i===1) {
//         console.log("Despegue")
//     }
    
// }



// WHILE



// while(continuar) {
//     let numero = parseInt(prompt("Ingrese la tabla de multiplicar que desea"))
//     for (let i=1; i<=5; i++) {
//         let resultado = i*numero
//         console.log(numero+"x"+i+": "+resultado)
//     }

//     let confirmacion = prompt("Desea hacer otro calculo? si/no")
//     if(confirmacion=="no") {
//         continuar=false
//         console.log("Gracias!!")
//     }
// }

let continuar = true 

while (continuar) {
    let menu = parseInt(prompt("Ingrese 1 para ver su cuenta, ingrese 2 para extracciones, ingrese 3 para deposito, otro numero para salir"))

    switch(menu) {
        case 1:
            console.log("Total de la cuenta: $3000")
            break 
        case 2:
            console.log("Limite de extraccion: $1000")
            break
        case 3:
            console.log("Limite de deposito: $500")
            break
        default:
            console.log("Retire su tarjeta")
            break
    }

    let confirmacion = prompt("Desea hacer otra consulta? si/no")
    if(confirmacion=="no") {
        continuar=false
        console.log("Gracias!!")
    }
}
